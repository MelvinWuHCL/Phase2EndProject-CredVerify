# Phase 2 End Project - Create a sample login and registration application

## Details

Simple user login and resgistration project that uses MySqL databases, hibernate, Java servlets, and Tomcat 9.0.

To use project, open in Eclipse Enterprise edition > Right click project folder > Choose "Run as" then pick "Run on Server" > Enter localhost:8080/test (should pop up in eclipse)
User will land to a page that directs them to a login page or a registration page.

When user goes to login page:
 * Type name and password.
 * Submit information.
 * If successful, redirect to a Home page
 * If unsuccessful, message pops up stating that login was unsuccessful.
 
 When user registers:
 * Type name, email, password
 * Submit information
 * If successful, information is addded to db
 * If unsuccessful, message will pop up saying user already exists.
